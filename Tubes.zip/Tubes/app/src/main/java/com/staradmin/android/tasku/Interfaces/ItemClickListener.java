package com.staradmin.android.tasku.Interfaces;

import android.view.View;

public interface ItemClickListener {

    void onItemClickListener(View v, int position);
}
