package com.staradmin.android.tasku.Activities.Profile;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import okhttp3.logging.HttpLoggingInterceptor;


public class Pustaka {

    //private static final String url = "http://aplysit.com/";
    private static final String url = "http://projectlab.co.id/";
    //    private static final String url = "http://192.168.90.247/";
    public static Retrofit retrofit = null;
    public void pindah (Context dari, Class ke, Boolean akhir){
        dari.startActivity(new Intent(dari, ke));
        if (akhir){
            ((Activity) (dari)).finish();
        }
    }

    public static Retrofit getService(){

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        Gson gson = new GsonBuilder().setLenient().create();
        OkHttpClient client = new OkHttpClient
                .Builder()
                .addInterceptor(interceptor)
                .build();
        if (retrofit == null){
            retrofit = new Retrofit.Builder()
                    .baseUrl(url)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;
    }

}
